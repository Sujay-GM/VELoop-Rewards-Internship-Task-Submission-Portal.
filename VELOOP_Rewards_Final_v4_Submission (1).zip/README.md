# VELOOP Rewards — Task 01 Revision 4

## Data authenticity
All operational records and calculated metrics in the workbook/database/dashboard are **SIMULATED**. They are not actual VELOOP production data or performance. The corrected synthetic workbook is a test fixture only; no production data/system was changed.

## New deliverables
- `34_Research_Insights_Action_Plan.docx` — public market/competitor research, evidence-linked insights, reward-economy caveats and actions.
- `31_Working_Analytics_Dashboard.xlsx` — working Excel KPI cards, charts, insight register and SQL result tabs.
- `32_Working_Dashboard.html` — locally openable interactive dashboard with categorical filtering and record exploration.
- `30_Analytics_Queries.sql` — 11 executable SQLite queries.
- `VELOOP_Analytics_Simulated.sqlite` — database used to execute the queries.
- `SQL_Result_Q01.csv` ... `SQL_Result_Q11.csv` — query outputs.
- `33_SQL_Execution_Results.xlsx` — query definitions and results.
- `VELOOP_Rewards_Corrected_Simulated_Workbook.xlsx` — corrected synthetic analytical test fixture; original source data preserved in the separate upload.

## Reconciliations / caution
- Task activity rows: 6,000; completed rows: 3,069; completed + valid: 1,058; completed not labelled valid: 2,011. These are row-level synthetic counts, not conversion rates.
- Wallet reversal rows: 839; 286 candidate parent links requiring business confirmation; 553 unresolved/quarantined. Do not call candidate links verified. The unresolved count is fixed at 553; the count is written explicitly in new deliverables.
- Amounts are always segmented by unit. No VE/SVE/Gems/Tokens/XP conversion is assumed.
- Public competitor research supports UX patterns only; market sizing is a third-party directional estimate, not VELOOP TAM.

## How to run SQL
Install SQLite or use a SQLite GUI, then run: `sqlite3 VELOOP_Analytics_Simulated.sqlite < 30_Analytics_Queries.sql`. The included CSVs and Excel results are outputs from query execution against the included database.

## How to open dashboard
Open `32_Working_Dashboard.html` in a modern browser. It uses embedded data and requires no server. For charts in Excel, open `31_Working_Analytics_Dashboard.xlsx` and select `Working Dashboard`.
