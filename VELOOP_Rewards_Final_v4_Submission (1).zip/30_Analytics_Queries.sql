-- VELOOP Rewards Task 01 — executable SQLite analysis
-- IMPORTANT: All rows are synthetic test data. Never report these as production performance.
-- Open with sqlite3 VELOOP_Analytics_Simulated.sqlite < 30_Analytics_Queries.sql

-- Q01: task lifecycle status counts and row shares
SELECT status, COUNT(*) AS task_rows, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM task_activity),2) AS row_share_pct
FROM task_activity GROUP BY status ORDER BY task_rows DESC;

-- Q02: task completion vs validation (completed is not the same as validated)
SELECT COUNT(*) AS all_task_rows,
       SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed_rows,
       SUM(CASE WHEN status='completed' AND validation_status='valid' THEN 1 ELSE 0 END) AS completed_and_valid,
       SUM(CASE WHEN status='completed' AND (validation_status IS NULL OR validation_status<>'valid') THEN 1 ELSE 0 END) AS completed_not_valid,
       ROUND(100.0*SUM(CASE WHEN status='completed' AND validation_status='valid' THEN 1 ELSE 0 END)/NULLIF(SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END),0),2) AS validation_pass_pct_of_completed
FROM task_activity;

-- Q03: task types with the largest observed row-level completion share
SELECT task_type, COUNT(*) AS rows,
       SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed_rows,
       ROUND(100.0*SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END)/COUNT(*),2) AS row_completion_share_pct,
       ROUND(AVG(reward_amount),2) AS mean_reward_amount
FROM task_activity GROUP BY task_type ORDER BY row_completion_share_pct DESC;

-- Q04: reward lifecycle by unit and status; amounts are NOT comparable across units
SELECT reward_unit, status, COUNT(*) AS reward_rows, ROUND(SUM(reward_amount),2) AS amount_in_unit
FROM rewards GROUP BY reward_unit,status ORDER BY reward_unit,status;

-- Q05: wallet transaction types and units; amounts remain unit-specific
SELECT transaction_type, unit, COUNT(*) AS transaction_rows, ROUND(SUM(amount),2) AS amount_in_unit
FROM wallet GROUP BY transaction_type,unit ORDER BY transaction_type,unit;

-- Q06: reversal reconciliation readiness (candidate links are not verified)
SELECT parent_transaction_resolution_status, COUNT(*) AS rows
FROM wallet WHERE transaction_type='reversal'
GROUP BY parent_transaction_resolution_status ORDER BY rows DESC;

-- Q07: withdrawal status, requested amount and average amount (amount units need business verification)
SELECT status, COUNT(*) AS withdrawal_rows, ROUND(SUM(requested_amount),2) AS amount_sum, ROUND(AVG(requested_amount),2) AS mean_amount
FROM withdrawals GROUP BY status ORDER BY withdrawal_rows DESC;

-- Q08: referral state distribution. Do not infer causal acquisition value from this alone.
SELECT status, COUNT(*) AS referral_rows, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM referrals),2) AS row_share_pct
FROM referrals GROUP BY status ORDER BY referral_rows DESC;

-- Q09: event failures by feature. 'not_applicable' is not automatically success/failure.
SELECT feature, COUNT(*) AS events,
       SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) AS success_events,
       SUM(CASE WHEN status='failure' THEN 1 ELSE 0 END) AS failure_events,
       ROUND(100.0*SUM(CASE WHEN status='failure' THEN 1 ELSE 0 END)/COUNT(*),2) AS failure_share_of_all_events_pct
FROM feature_events GROUP BY feature ORDER BY failure_share_of_all_events_pct DESC;

-- Q10: registration source and current account status
SELECT registration_source, account_status, COUNT(*) AS users
FROM users GROUP BY registration_source,account_status ORDER BY registration_source,users DESC;

-- Q11: completed withdrawal elapsed time; only completed rows with valid non-negative durations
SELECT COUNT(*) AS eligible_completed_rows,
       ROUND(AVG((julianday(final_timestamp)-julianday(requested_timestamp))*24),2) AS mean_hours,
       ROUND(AVG((julianday(final_timestamp)-julianday(requested_timestamp))*1440),2) AS mean_minutes
FROM withdrawals WHERE status='completed' AND final_timestamp IS NOT NULL AND requested_timestamp IS NOT NULL
AND julianday(final_timestamp)>=julianday(requested_timestamp);
